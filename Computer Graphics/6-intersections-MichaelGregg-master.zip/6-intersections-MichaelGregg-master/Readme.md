# Lab 6: Calculate intersections

Modify intersections.cpp:
* replace the dummy return value in rayPolygonIntersection() to actually find the intersection with the given polygon
* modify checkIntersections to only log the closest intersection

## Due Sunday April 9 11:59pm

## Remember to make changes in hw branch!

# Homework 2: Minimax TicTacToe

Fill in the empty methods in TicTacToe.h. Follow the pseudocode in the adversarial search slides (linked from the website). Make sure to enable travis, open a pull request, and mention @rivlev in the body of the pull request, along with your full name.

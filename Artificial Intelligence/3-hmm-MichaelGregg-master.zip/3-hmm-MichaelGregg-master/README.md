# 3-hmm

Implement methods filter and viterbi in hmm.cpp.

When implemented correctly, the output from main.cpp should match the sample output in output.txt.
